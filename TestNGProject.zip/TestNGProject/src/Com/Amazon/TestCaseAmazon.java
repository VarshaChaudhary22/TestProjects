package Com.Amazon;

import java.rmi.AccessException;
import java.time.Duration;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;


public class TestCaseAmazon {
	WebDriver driver;
	
	
	@BeforeSuite
	public void Setup()
	{
		
		// To initialize the browser
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\VARSHA\\Downloads\\Chrome 115+\\chromedriver-win64_117\\chromedriver-win64\\chromedriver.exe");
		ChromeOptions co=new ChromeOptions();
		co.setBinary("C:\\Users\\VARSHA\\Downloads\\Chrome 115+\\chrome-win64 117\\chrome-win64\\chrome");
		driver=new ChromeDriver();
		
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(30));
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		}
	
	// Here Our Test cases are started in different Test methods and we are using parametrization
	// And Setting the priority
	@Parameters({"URL","Uname","Pwd"})
	@Test(priority=1,groups="Search for Product")
	public void Login(String URL, String Uname, String Pwd) 
	{
		//Launch Amazon.in
		driver.get(URL);
		driver.findElement(By.id("nav-link-accountList")).click();
		// Login to Application
		 WebElement emailField = driver.findElement(By.id("ap_email"));
		 //Username
         emailField.sendKeys(Uname);
         driver.findElement(By.id("continue")).click();
         //Password
         WebElement passwordField = driver.findElement(By.id("ap_password"));
         passwordField.sendKeys(Pwd);
          // Submit button
         WebElement signInSubmit = driver.findElement(By.id("signInSubmit"));
         signInSubmit.click();
		}
	
	// Here Searching for the product and verify whether product displayin is correct
	@Parameters({"SearchProduct"})
	@Test(priority=2, groups="Search for Product")
	public void SearchItem(String SearchProduct) 
	{
	   // Entering Text for Search using Parametrization
		WebElement searchBox = driver.findElement(By.id("twotabsearchtextbox"));
        searchBox.sendKeys(SearchProduct);
        searchBox.sendKeys(Keys.RETURN);
        
        WebElement ResProducts = driver.findElement(By.cssSelector(".s-result-list"));
        //Verifying the result
        if (ResProducts.getText().toLowerCase().contains(SearchProduct.toLowerCase())) {
        	Assert.assertTrue(true);
            System.out.println("Search results contain the expected product");
        }
	}
	
	// Applying Filter on price and verification
	
	@Test(priority=3,groups="Apply Filter")
	public void ApplyFilter() throws InterruptedException {
		 
		Thread.sleep(5000);
		WebElement PriceFilterMin = driver.findElement(By.id("low-price"));
		PriceFilterMin.sendKeys("500");
		WebElement PriceFilterMax = driver.findElement(By.id("high-price"));
		PriceFilterMax.sendKeys("1500");
		
		driver.findElement(By.xpath("//input[@class='a-button-input']")).click();
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='s-main-slot s-result-list s-search-results sg-row']")));
		
		//Storing the List and iterate through the list to check price
		/*List<WebElement> ProductPriceList = driver.findElements(By.cssSelector(".a-offscreen"));
		 for(int i=0;i<=ProductPriceList.size();i++)
		 {
			String ProductPrice=ProductPriceList.get(i).getText();
			System.out.println(ProductPrice);
			
			double numericValue = Double.parseDouble(ProductPrice);
			if(numericValue >=500 && numericValue<=1500)
			{
				Assert.assertTrue(true);
				System.out.println("Filtered Apply Correctly");
			}}	*/	
	}
	
	// Here Selecting Size and Color and then adding to cart
	@Test(priority=4,groups="Adding Product")
	public void AddingProduct() throws InterruptedException 
	{
		Thread.sleep(6000);
		driver.findElement(By.xpath("//img[contains(@src,'https://m.media-amazon.com/images/I/71WBVg0YE8L._AC_UL320_.jpg')]")).click();
		Thread.sleep(6000);
		// Handling window when click on product
		String mainwindow=driver.getWindowHandle();
		 Set<String> windowHandles = driver.getWindowHandles();

         for (String windowHandle : windowHandles) {
             if (!windowHandle.equals(mainwindow))
             {
            	// Switch to the new window
            	 driver.switchTo().window(windowHandle);
                 Thread.sleep(10000);
                 WebElement SizeDropdown=driver.findElement(By.xpath("//select[@id='native_dropdown_selected_size_name']"));
              
              // Selecting the Size of product
                 Select select=new Select(SizeDropdown);
                 select.selectByVisibleText(" XL ");
              
              // Selecting the Color of Product   
                 driver.findElement(By.xpath("//img[@alt='Teal']")).click(); 
                 Thread.sleep(6000);
                 
              // Adding product to Cart
                 driver.findElement(By.id("add-to-cart-button")).click();
                 WebElement ActualValue=driver.findElement(By.xpath("//span[@class='a-size-medium-plus a-color-base sw-atc-text a-text-bold']"));
                String stringvalue=ActualValue.getText();
                
               // Verifying Product added to cart or not
                 Assert.assertEquals(stringvalue, "Added to Cart"); 
                 System.out.println("Product is added to cart");
             
             }
             
             
         }}
	
	// Here Verify the Product Details -Correct product added or not 
@Test(priority=5,dependsOnMethods="AddingProduct",groups="ProductCheck")

    public void ProductCheck() throws InterruptedException
      {
	   try {
	     driver.findElement(By.xpath("//a[@href='/cart?ref_=sw_gtc']")).click();
	     Thread.sleep(5000);
	     
	//Verifying the Acutal and Expected -Correct product Name is dispalying 
	    String AddedProductDetail= driver.findElement(By.xpath("//span[@class='a-truncate-cut']")).getText();
	     Assert.assertEquals(AddedProductDetail, "Van Heusen Men's Regular Fit Polo T-Shirt (VSKPWRGFR16516_Teal XL)", "Correct Product Added");
	     System.out.println("Product matched");
	 
	// Verify the Size of is matched with Product added
	     String sizeadded=driver.findElement(By.xpath("//span[normalize-space()='XL']")).getText();
	     Assert.assertEquals(sizeadded, "XL");
	     System.out.println("XL size added-Details Matched");
	   }
	   catch(Exception e)
	   {
		   e.getMessage();
	   }
	     
          }

// Here Adding Address Details and Selecting Payment
    @Parameters({"FullName","MobileNo","AddressLine","PinCode","City","State"})
	@Test(priority=6,dependsOnMethods="ProductCheck", groups="Payment details")
	public void PaymentDetails(String FullName,String MobileNo, String AddressLine,String PinCode,String City, String State) throws InterruptedException 
	{
		//Click on Proceed To Buy
		driver.findElement(By.xpath("//input[@name='proceedToRetailCheckout']")).click();
		//To add New Address
		driver.findElement(By.id("add-new-address-popover-link")).click();
		Thread.sleep(5000);
		
		//To Add Details in Add New Adddress
		WebElement fullName = driver.findElement(By.xpath("//input[@id='address-ui-widgets-enterAddressFullName']"));
        WebElement phoneNumber = driver.findElement(By.xpath("//input[@id='address-ui-widgets-enterAddressPhoneNumber']"));
        WebElement addressLine1 = driver.findElement(By.xpath("//input[@id='address-ui-widgets-enterAddressLine1']"));
        WebElement city = driver.findElement(By.xpath("//input[@id='address-ui-widgets-enterAddressCity']"));
        WebElement postalCode = driver.findElement(By.xpath("//input[@id='address-ui-widgets-enterAddressPostalCode']"));
        WebElement UseThisAddress = driver.findElement(By.xpath("//*[contains(@id,'address-ui-widgets-form-submit-button-announce')]"));
        
        fullName.sendKeys(FullName);
        phoneNumber.sendKeys(MobileNo);
        addressLine1.sendKeys(AddressLine);
       // city.sendKeys(City);
        postalCode.sendKeys(PinCode);
        // For Selecting State from the list
       
        /* WebElement Sdropdown=driver.findElement(By.xpath("//select[@id='address-ui-widgets-enterAddressStateOrRegion-dropdown-nativeId']"));
        Select select=new Select(Sdropdown);
        select.selectByValue(State);  */ 
        
        
        //To handle use this Address button
        Actions actions = new Actions(driver); 
        actions.moveToElement(UseThisAddress).click().build().perform();
        actions.moveToElement(UseThisAddress).click().build().perform();
       
        
        Thread.sleep(5000);
        // To Scrill down on Page 
        /*JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("arguments[0].scrollIntoView();", UseThisAddress); 
                
        */
       
        Thread.sleep(5000);
        // To click on Use this address
        //driver.findElement(By.xpath("//input[@data-testid='Address_selectShipToThisAddress']')][1]")).click();
        //To Click on Use this payment
        //driver.findElement(By.id("//span[@class='a-button-inner']//input[@name='ppw-widgetEvent:SetPaymentPlanSelectContinueEvent']']")).click();        
		}
	
  // To close the Browser  
    @AfterClass
     public void closebrowser(){
      driver.quit();
        	}
	}
       
	

